# engr432-image
Simple Python package for image blurring, color shifting.

# Diagrams

## ImageObject
![ImageObject Diagram](docs/ImageObject.png)

## Flow Chart
![Flow Chart](docs/flow_chart.png)
